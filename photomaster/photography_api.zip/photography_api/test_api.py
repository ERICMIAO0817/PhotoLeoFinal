#!/usr/bin/env python3
"""
摄影智能引导 API 测试脚本
用于测试API的各项功能
"""

import requests
import json
import base64
import os
import sys
from PIL import Image
import io

# API配置
API_BASE_URL = "http://localhost:5002"

def test_health_check():
    """测试健康检查接口"""
    print("🔍 测试健康检查接口...")
    
    try:
        response = requests.get(f"{API_BASE_URL}/api/health", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ 健康检查成功: {data['message']}")
            return True
        else:
            print(f"❌ 健康检查失败: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 健康检查异常: {e}")
        return False

def create_test_image():
    """创建一个测试图片"""
    print("🖼️ 创建测试图片...")
    
    # 创建一个简单的测试图片
    img = Image.new('RGB', (300, 200), color='lightblue')
    
    # 保存到内存
    img_buffer = io.BytesIO()
    img.save(img_buffer, format='JPEG')
    img_buffer.seek(0)
    
    # 转换为base64
    img_data = img_buffer.getvalue()
    img_base64 = base64.b64encode(img_data).decode('utf-8')
    
    print("✅ 测试图片创建成功")
    return img_base64, img_data

def test_json_analysis():
    """测试JSON格式的图片分析"""
    print("\n🔍 测试JSON格式图片分析...")
    
    img_base64, _ = create_test_image()
    
    payload = {
        "image": f"data:image/jpeg;base64,{img_base64}",
        "prompt": "分析这张测试图片的构图和颜色"
    }
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/api/analyze",
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            print("✅ JSON分析成功")
            print(f"📊 处理时间: {data.get('processing_time', 'N/A')}秒")
            print(f"📝 建议数量: {len(data.get('guidance', {}).get('steps', []))}")
            return True
        else:
            print(f"❌ JSON分析失败: {response.status_code}")
            print(f"错误信息: {response.text}")
            return False
    except Exception as e:
        print(f"❌ JSON分析异常: {e}")
        return False

def test_formdata_analysis():
    """测试FormData格式的图片分析"""
    print("\n🔍 测试FormData格式图片分析...")
    
    _, img_data = create_test_image()
    
    files = {
        'image': ('test_image.jpg', img_data, 'image/jpeg')
    }
    data = {
        'prompt': '分析这张测试图片的构图和颜色'
    }
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/api/analyze",
            files=files,
            data=data,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            print("✅ FormData分析成功")
            print(f"📊 处理时间: {data.get('processing_time', 'N/A')}秒")
            print(f"📝 建议数量: {len(data.get('guidance', {}).get('steps', []))}")
            return True
        else:
            print(f"❌ FormData分析失败: {response.status_code}")
            print(f"错误信息: {response.text}")
            return False
    except Exception as e:
        print(f"❌ FormData分析异常: {e}")
        return False

def test_error_handling():
    """测试错误处理"""
    print("\n🔍 测试错误处理...")
    
    # 测试无效的JSON
    try:
        response = requests.post(
            f"{API_BASE_URL}/api/analyze",
            json={"invalid": "data"},
            timeout=10
        )
        
        if response.status_code == 400:
            print("✅ 无效JSON错误处理正确")
        else:
            print(f"⚠️ 无效JSON错误处理异常: {response.status_code}")
    except Exception as e:
        print(f"❌ 无效JSON测试异常: {e}")
    
    # 测试无效的图片数据
    try:
        payload = {
            "image": "invalid_base64_data",
            "prompt": "测试"
        }
        response = requests.post(
            f"{API_BASE_URL}/api/analyze",
            json=payload,
            timeout=10
        )
        
        if response.status_code in [400, 415]:
            print("✅ 无效图片数据错误处理正确")
        else:
            print(f"⚠️ 无效图片数据错误处理异常: {response.status_code}")
    except Exception as e:
        print(f"❌ 无效图片数据测试异常: {e}")

def main():
    """主测试函数"""
    print("🧪 摄影智能引导 API 测试")
    print("=" * 50)
    
    # 检查API是否运行
    if not test_health_check():
        print("\n❌ API服务器未运行或无法访问")
        print("请先启动API服务器: python api_server.py")
        return 1
    
    # 运行各项测试
    tests = [
        ("JSON格式分析", test_json_analysis),
        ("FormData格式分析", test_formdata_analysis),
        ("错误处理", test_error_handling)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
        except Exception as e:
            print(f"❌ {test_name}测试异常: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有测试通过！API运行正常")
        return 0
    else:
        print("⚠️ 部分测试失败，请检查API配置")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 