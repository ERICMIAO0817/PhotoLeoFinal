#!/usr/bin/env python3
"""
摄影智能引导 API 服务器
专为团队提供的独立API接口
"""

import os
import sys
import tempfile
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
import traceback

# 添加项目根目录和data目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)
sys.path.append(os.path.join(current_dir, 'data'))

# 导入摄影代理
try:
    from data.photography_agent import PhotographyAgent
except ImportError:
    try:
        from photography_agent import PhotographyAgent
    except ImportError:
        print("❌ 无法导入摄影代理模块")
        sys.exit(1)

# 创建Flask应用
app = Flask(__name__)
CORS(app)  # 允许跨域访问

# 全局变量
photography_agent = None

def init_agent():
    """初始化摄影代理"""
    global photography_agent
    try:
        photography_agent = PhotographyAgent()
        return True
    except Exception as e:
        print(f"❌ 摄影代理初始化失败: {e}")
        traceback.print_exc()
        return False

@app.route('/api/analyze', methods=['POST'])
def analyze_image():
    """
    图片分析API
    接收图片文件，返回摄影建议JSON
    """
    try:
        # 检查代理是否可用
        if not photography_agent:
            return jsonify({
                'status': 'error',
                'message': 'AI代理未初始化',
                'timestamp': datetime.now().isoformat()
            }), 500

        # 检查是否有文件上传
        if 'image' not in request.files:
            return jsonify({
                'status': 'error',
                'message': '请上传图片文件',
                'timestamp': datetime.now().isoformat()
            }), 400

        file = request.files['image']
        
        # 检查文件名
        if file.filename == '':
            return jsonify({
                'status': 'error',
                'message': '未选择文件',
                'timestamp': datetime.now().isoformat()
            }), 400

        # 检查文件类型
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}
        if not ('.' in file.filename and 
                file.filename.rsplit('.', 1)[1].lower() in allowed_extensions):
            return jsonify({
                'status': 'error',
                'message': '不支持的文件格式，请上传图片文件',
                'timestamp': datetime.now().isoformat()
            }), 400

        # 保存临时文件
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as tmp_file:
            file.save(tmp_file.name)
            
            try:
                # 调用摄影代理分析图片
                guidance = photography_agent.get_guidance(tmp_file.name)
                
                # 返回成功响应
                return jsonify({
                    'status': 'success',
                    'data': guidance,
                    'timestamp': datetime.now().isoformat(),
                    'filename': file.filename
                })
                
            finally:
                # 清理临时文件
                try:
                    os.unlink(tmp_file.name)
                except:
                    pass

    except Exception as e:
        print(f"❌ API错误: {e}")
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': f'服务器内部错误: {str(e)}',
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    agent_status = 'ready' if photography_agent else 'not_initialized'
    
    return jsonify({
        'status': 'ok',
        'agent_status': agent_status,
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@app.route('/api/info', methods=['GET'])
def api_info():
    """API信息接口"""
    return jsonify({
        'name': '摄影智能引导API',
        'version': '1.0.0',
        'description': '提供图片分析和摄影建议的API服务',
        'endpoints': {
            '/api/analyze': {
                'method': 'POST',
                'description': '分析图片并返回摄影建议',
                'content_type': 'multipart/form-data',
                'parameters': {
                    'image': '图片文件 (支持: png, jpg, jpeg, gif, bmp, webp)'
                },
                'response': {
                    'status': 'success/error',
                    'data': '摄影建议JSON对象',
                    'timestamp': 'ISO格式时间戳',
                    'filename': '上传的文件名'
                }
            },
            '/api/health': {
                'method': 'GET',
                'description': '健康检查',
                'response': {
                    'status': 'ok',
                    'agent_status': 'ready/not_initialized',
                    'timestamp': 'ISO格式时间戳'
                }
            },
            '/api/info': {
                'method': 'GET',
                'description': 'API信息和使用说明'
            }
        },
        'usage_example': {
            'curl': "curl -X POST -F 'image=@your_photo.jpg' http://localhost:5002/api/analyze",
            'python': """
import requests

with open('your_photo.jpg', 'rb') as f:
    response = requests.post(
        'http://localhost:5002/api/analyze',
        files={'image': f}
    )
    result = response.json()
    print(result)
            """
        },
        'timestamp': datetime.now().isoformat()
    })

@app.errorhandler(413)
def request_entity_too_large(error):
    """处理文件过大错误"""
    return jsonify({
        'status': 'error',
        'message': '上传文件过大，请压缩后重试',
        'timestamp': datetime.now().isoformat()
    }), 413

@app.errorhandler(404)
def not_found(error):
    """处理404错误"""
    return jsonify({
        'status': 'error',
        'message': 'API接口不存在',
        'available_endpoints': ['/api/analyze', '/api/health', '/api/info'],
        'timestamp': datetime.now().isoformat()
    }), 404

if __name__ == '__main__':
    print("🚀 摄影智能引导API服务器启动中...")
    
    # 初始化摄影代理
    if not init_agent():
        print("❌ 无法启动API服务器，摄影代理初始化失败")
        sys.exit(1)
    
    print("✅ 摄影代理初始化成功")
    print("📡 API服务器信息:")
    print("   - 地址: http://localhost:5002")
    print("   - 图片分析: POST /api/analyze")
    print("   - 健康检查: GET /api/health")
    print("   - API信息: GET /api/info")
    print("🔧 使用示例:")
    print("   curl -X POST -F 'image=@photo.jpg' http://localhost:5002/api/analyze")
    print("📚 完整文档: http://localhost:5002/api/info")
    
    # 设置文件上传限制 (16MB)
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
    
    # 启动服务器
    app.run(
        host='0.0.0.0',
        port=5002,
        debug=True,
        threaded=True
    )